from django.contrib import admin
from .models import Human


class HumanAdmin(admin.ModelAdmin):
    list_display = ('id', 'First_name', 'Last_name2', 'Last_name', 'Residence', 'Birthdate', 'Characteristic',
                    'Photo', 'Registration')
    list_display_links = ('id', 'Last_name2', 'Birthdate', 'Registration')
    search_fields = ('First_name', 'Last_name2', 'Residence', 'Birthdate', 'Characteristic', 'Registration')


admin.site.register(Human, HumanAdmin)

